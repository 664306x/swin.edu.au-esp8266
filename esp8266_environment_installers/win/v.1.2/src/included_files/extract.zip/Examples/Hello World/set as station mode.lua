wifi.setmode(wifi.STATION) -- set mode as station
wifi.sta.config("SSID","password") -- configure network credential to connect to access point network
