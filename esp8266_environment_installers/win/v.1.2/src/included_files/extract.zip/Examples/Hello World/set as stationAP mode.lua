wifi.setmode(wifi. STATIONAP) -- set mode to station access point
wifi.sta.config("SSID","password") -- configure network credential to connect to access point network
wifi.ap.config({ssid= "ESP_TEST", pwd="123456789"}) -- configure own SSID as �ESP_TEST� and password of �123456789�
