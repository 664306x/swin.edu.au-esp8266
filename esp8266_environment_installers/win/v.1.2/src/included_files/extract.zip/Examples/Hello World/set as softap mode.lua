wifi.setmode(wifi.SOFTAP) -- set mode as access point
wifi.ap.config({ssid= "ESP_TEST", pwd="123456789"}) -- configure own SSID as �ESP_TEST� and password of �123456789�
