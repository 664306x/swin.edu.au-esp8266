pin = 6 -- assign 6 into variable pin   
gpio.mode(pin, gpio.OUTPUT) -- set pin index 6 to GPIO mode   
led_state = gpio.read(pin) -- read GPIO12 state (0,1) and assign it into led_state   
if led_state == gpio.LOW then -- if led_state is equal to low (0)   
led_state = gpio.HIGH -- assign led_state to gpio.high   
gpio.write(pin, led_state) -- set GPIO12 to high   
else   
led_state = gpio.LOW -- assign led_state to gpio.low   
gpio.write(pin, led_state) -- set GPIO12 to low   
end -- end of statement