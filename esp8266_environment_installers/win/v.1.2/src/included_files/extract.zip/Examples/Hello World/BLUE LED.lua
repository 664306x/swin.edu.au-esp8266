pin = 7
gpio.mode(pin, gpio.OUTPUT)
led_state = gpio.read(pin)
if led_state == gpio.LOW then
led_state = gpio.HIGH
gpio.write(pin, led_state)
else
led_state = gpio.LOW
gpio.write(pin, led_state)
end
